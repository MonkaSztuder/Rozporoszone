# Rozporoszone
 Programowanie Rozproszone Krasnale
