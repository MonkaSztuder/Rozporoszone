
#pragma once

/* pętla główna aplikacji: zmiany stanów itd */
void mainLoop();
